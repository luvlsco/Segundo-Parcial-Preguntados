from src.main import Juego

if __name__ == "__main__":
    juego = Juego()
    juego.ejecutar()