import pygame 

def main_menu():
    pygame.display.set_caption("Menu")

    while True:

        


