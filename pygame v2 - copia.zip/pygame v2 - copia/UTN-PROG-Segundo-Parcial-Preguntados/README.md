<h1 align="center">
    <a><img alt="Logo del proyecto" src="https://i.imgur.com/CDLN5hf.png"></a>
    <a target="_blank" rel="noopener noreferrer" href="https://www.python.org/"><img alt="Enlace a Python" title="Python" src="https://i.imgur.com/boygpQN.png" width="200"></a>
    <a target="_blank" rel="noopener noreferrer" href="https://fra.utn.edu.ar/">
    <img alt="Enlace a la página de la facultad" title="Universidad Tecnológica Nacional: Facultad Regional Avellaneda" src="https://fra.utn.edu.ar/wp-content/uploads/2023/07/utn_logo_svg.svg" width="170"></a>
    <a target="_blank" rel="noopener noreferrer" href="https://www.pygame.org/news"><img alt="Enlace a Pygame"title="Pygame" src="https://www.pygame.org/docs/_static/pygame_powered.svg" width="240"></a>
</h1>