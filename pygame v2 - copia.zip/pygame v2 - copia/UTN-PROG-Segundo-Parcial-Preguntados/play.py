from src.main import *

inicializar_juego()

while(True):
    actualizar_pantalla()
    cerrar_juego()