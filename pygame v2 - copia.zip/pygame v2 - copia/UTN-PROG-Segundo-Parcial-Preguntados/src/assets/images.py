import pygame

pygame.init()

utn_icono = pygame.image.load("assets/images/icons/icono_utn.png")