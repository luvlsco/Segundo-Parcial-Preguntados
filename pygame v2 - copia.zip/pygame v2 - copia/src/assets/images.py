import pygame

pygame.init()

utn_icono = pygame.image.load("assets/images icon/icono_utn.png")